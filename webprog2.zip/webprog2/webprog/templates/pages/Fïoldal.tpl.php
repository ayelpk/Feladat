<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menhely</title>
    <link rel="stylesheet" href="styles/style.css" type="text/css">
  </head>
<body>
<div id="container">
    <header>
        <a href="#" id="logo"><img src="images/logo.png" alt="" width="262" height="133"></a>
        </header>
<section id="intro">
        <div>
            <img src="images/banner2.jpg" alt=""
             style="position: centre; top: 0px; left: 960px; z-index: 5; display: block;" width="960" height="300">

          </div>
</section> 
 </div>
  <div class="doboz">
        <section class="csoport1">
          <h3>Hírek</h3>
          <a class="photo_hover3" href="#"><img src="images/picture5.jpg" alt="" width="190" height="105"></a>

<p>
            <h3>FOGADJ ÖRÖKBE KISOKOS - vagy mit csináljunk ha örökbe szeretnénk fogadni!</h3> 
     
             Először is nézd meg az oldalunkat, vagy a Facebookos oldalunkat - remélhetőleg beleszeretsz valamelyik kutyusunkba.
             Majd keress minket telefonon ( 06-12/345-67-89 ) vagy emailen ( info@mogyoromenhely.hu ) és beszélgessünk.
             Megbeszéljük hova szeretnél , mit szeretnél, milyet szeretnél, és mi is ajánlunk neked megfelelő társjelöltet.
             A személyes találkozás alkalmával lehetőséged lesz megismerni a kiválasztott kutyust- kutyusokat.
             Előellenörzést fogunk tartani, vagyis NAGYON megnézzük hova kerülne a választott, és ha minden rendben, 10.000.- ellenében haza is viheted a minimum 3 oltással ellátott, féreghajtott, parazitamentesített és ha kora engedi ivartalanított kutyust.
             Utóellenörzés alkalmával meglátogatjuk régi védencünket és megnézzük milyen jó az élete - mert a szerető család mindennél többet ér! Ha kérdésed van keress minket!
             
            <a href="indexbővebben.html">Bővebben</a> 
             </p>

             <p>
                <h3>PÁLYÁZATI FELHÍVÁS</h3> 
     
                 PÁLYÁZATI FELHÍVÁS, állatvédő szervezetek részére! Vigyétek hírét, hogy minél több szervezethez eljusson!
                 Folyamatos PÉNZBELI támogatási lehetőség ÁLLATVÉDŐ SZERVEZETEKNEK, a Netfone Telecomnak köszönhetően!
                 Oszd meg, küldd el, hívd fel a figyelmét a környezetedben működő, felelős állatvédő szervezetnek!
                 A Netfone évek óta támogatja a Mogyoró Menhely, sokat beszélgettünk a magyarországi állatvédelem szinte kilátástalan helyzetéről és most szintet lépnek.
                 A most induló #Pettel mobilszolgáltató márka a Netfone egy almárkája. Egy állandósított támogatói struktúrára épül, ahol minden mobil előfizető minden havi költségéből azonos összeg kerül felajánlásra, továbbá az előfizetők maguk dönthetik el szerződéskötéskor, hogy az általa megfizetett havidíjból mely szerződött szervezetet szeretné támogatni.
                 Erre regisztrálhatnak most az állatvédő szervezetek!
              
                 Részletek hamarosan.

                 
     
             </p>
             <video controls autoplay preload="auto" loop muted>
                <source src="images/video.MOV" type="video/MOV">
           
               </video>

             <p>
                <h3>NYILATKOZAT ADÓ 1 %</h3> 
                
                 Itt az adóbevallás ideje! Rendelkezz adód 1%-ról, ezzel is ÉLETET MENTHETSZ!
                 Rendelkezési határidő, az adóbevallás leadásától függetlenül, 2023.05.20.! ⚠️
                 Mogyoró Menhely
                 adószám: 98745632-1-00
                 #acsodákategyüttcsináljuk!
                 Adód 1%-a ÉLETET MENTHET!
                 Személyei jövedelemadód 1%-val, most Te is segíthetsz, hogy minél több rászoruló kaphasson még egy esélyt!
                 Rendelkezési határidő, az adóbevallás leadásától függetlenül, 2023.05.20.!
                 Mogyoró Menhely
                 adószám: 98745632-1-00
                 <a href="https://www.youtube.com/shorts/dklomBtFzeU">
             </p>

             <p>
  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10785.094290753008!2d19.3106419!3d47.4845837!
  3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741c727e291f24d%3A0xed53048b254a1976!2zTk_DiSDDgWxsYXRvdHRob24gQWxhcMOtdHb
  DoW55!5e0!3m2!1shu!2shu!4v1683561369671!5m2!1shu!2shu" width="600" height="450" style="border:0;" 
  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</p>
             </section>
      </div>

    
        

    </div>

</div>

<footer>
    <div class="container">
      <aside class="footer_left">
        <h4>Mogyoró Menhely <span>Lorem ipsum dolor sit amet</span> <span>Lorem ipsum dolor sit amet</span> </h4>
      </aside>
      <aside class="footer_left">
        <h4>Bla bla <span>Lorem ipsum dolor sit amet</span> <span>Lorem ipsum dolor sit amet</span> </h4>
      </aside>
      <aside class="footer_left">
        <h4>Purr purr <span>© Copyright 2023 Mogyoró Menhely</span> <span>Lorem ipsum dolor sit amet</span> </h4>
      </aside>
      <img src="images/cat_paw_prints.png" alt="" class="picture_footer" width="300" height="300">
      <div id="FooterTwo"> © 2012 cats template </div>
      <div id="FooterTree">Website Template By <a target="_blank" href="http://www.noeallatotthon.hu/">Noé Állatotthon</a></div>
    </div>
  </footer>

    
</body>


</html>
