<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menhely</title>
    <link rel="stylesheet" href="styles/style.css" type="text/css">
</head>
<body>
    <body>
        <div id="container">
            <header>
                <a href="#" id="logo"><img src="images/logo.png" alt="" width="262" height="133"></a>
        
        </header>
        </div>
    <a href="index.html">vissza</a>
    Először is nézd meg az oldalunkat, 
    vagy a Facebookos oldalunkat - remélhetőleg beleszeretsz valamelyik kutyusunkba. 
    Majd keress minket telefonon ( 06-12/345-67-89 ) vagy emailen ( info@mogyoromenhely.hu ) és beszélgessünk. 
    Megbeszéljük hova szeretnél , mit szeretnél, milyet szeretnél, és mi is ajánlunk neked megfelelő társjelöltet. 
    A személyes találkozás alkalmával lehetőséged lesz megismerni a kiválasztott kutyust- kutyusokat. Előellenörzést fogunk tartani, 
    vagyis NAGYON megnézzük hova kerülne a választott, és ha minden rendben, 10.000.- ellenében haza is viheted a minimum 3 oltással 
    ellátott, féreghajtott, parazitamentesített és ha kora engedi ivartalanított kutyust. Utóellenörzés alkalmával meglátogatjuk
     régi védencünket és megnézzük milyen jó az élete - mert a szerető család mindennél többet ér! Ha kérdésed van keress minket!
    
</body>
</html>