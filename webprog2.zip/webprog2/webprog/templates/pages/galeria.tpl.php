<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menhely</title>
    <link rel="stylesheet" href="styles/style.css" type="text/css">
</head>
<body>

    <a href="index.html">vissza</a>

    <div id="container">
        <header>
            <a href="#" id="logo"><img src="images/logo.png" alt="" width="262" height="133"></a>
    
    </header>
    </div>
<p>
            <h3>Galéria/h3> 
     
             Ide lehet feltölteni a saját képeket.
           
             </p>
</body>
</html>