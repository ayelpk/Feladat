<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menhely</title>
    <link rel="stylesheet" href="styles/style.css" type="text/css">
</head>
<body>
    <div id="container">
        <header>
            <a href="#" id="logo"><img src="images/logo.png" alt="" width="262" height="133"></a>
    
    </header>
    </div>
    <a href="index.html">vissza</a>

    <h2>Újdonsült Gazdiktól várjuk a képeket!</h2>
  
        
          <p>
            <h3>Muki Gazdis!</h3> 
     
             Muki 2 évet várt, hogy családja legyen. Végre hazaért 🙏❤️ mostantól német állampolgár lesz 🥰
              elmondhatatlan boldogság, hogy végre más is meglátta a csodát rajtunk kívül 
           
             </p>

             <p>
                <h3>Cirmi Gazdis</h3> 
     
                Szerencsére Cirmi élete jó fordulatot vett, meggyógyult és ma már gazdis híreket is kaptunk.
                 
     
             </p>
             

             <p>
                <h3>Pötyi Gazdis</h3> 
                
                Pötyiről szerencsére folyamatosan kapjuk a gazdis beszámolókat 
                így most is nagyon örültünk, hogy a gazdis élete csupa boldogság.
             </p>
      
      </div>
</body>
</html>

<?php
    // Alkalmazás logika:
    include('config.inc.php');
    
    // adatok összegyűjtése:    
    $kepek = array();
    $olvaso = opendir($MAPPA);
    while (($fajl = readdir($olvaso)) !== false)
        if (is_file($MAPPA.$fajl)) {
            $vege = strtolower(substr($fajl, strlen($fajl)-4));
            if (in_array($vege, $TIPUSOK))
                $kepek[$fajl] = filemtime($MAPPA.$fajl);            
        }
    closedir($olvaso);
    
    // Megjelenítés logika:
?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Galéria</title>
    <style type="text/css">
        div#galeria {margin: 0 auto; width: 620px;}
        div.kep { display: inline-block; }
        div.kep img { width: 200px; }
    </style>
</head>
<body>
    <div id="galeria">
    <h1>Galéria</h1>
    <?php
    arsort($kepek);
    foreach($kepek as $fajl => $datum)
    {
    ?>
        <div class="kep">
            <a href="<?php echo $MAPPA.$fajl ?>">
                <img src="<?php echo $MAPPA.$fajl ?>">
            </a>            
            <p>Név:  <?php echo $fajl; ?></p>
            <p>Dátum:  <?php echo date($DATUMFORMA, $datum); ?></p>
        </div>
    <?php
    }
    ?>
    </div>
</body>
</html>