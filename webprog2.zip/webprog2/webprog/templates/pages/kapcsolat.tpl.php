<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menhely</title>
    <link rel="stylesheet" href="styles/style.css" type="text/css">
</head>
<body>
    <a href="index.html">vissza</a>
    
    <body>
        <div id="container">
            <header>
                <a href="#" id="logo"><img src="images/logo.png" alt="" width="262" height="133"></a>
        
        </header>
        </div>
    <form action="kapcsolat.html" method="POST">
        <div class="form-group">
            <label>Név</label>
            <br>
            <input type="text" name="Név">
        </div>
        <div class="form-group"> 
            <label>jelszó</label>
            <br>
            <input type="password" name="password">
        </div>
            <div class="form-group"> <label>Üzenet</label>
                <br>
            <textarea name="üzenet"></textarea> 
        </div>
            <input type="submit" value="Küldés" method="POST">




</body>
</html>