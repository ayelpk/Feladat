<?php
$ablakcim = array(
    'cim' => 'Mogyoró Menhely',
);

$fejlec = array(
    'kepforras' => 'images/logo.png',
    'kepalt' => 'logo',
	'cim' => 'Mogyoró Menhely',
	
);

$lablec = array(
    'kepforras' => 'images/cat_paw_prints.png',
    'kepalt' => 'cat_paw_prints',
    
);

$oldalak = array(
	'Főoldal' => array('fajl' => 'Főoldal', 'szoveg' => 'Főoldal', 'menun' => array(1,1)),
	'Örökbefogadhatókutyák' => array('fajl' => 'Örökbefogadhatókutyák', 'szoveg' => 'Örökbefogadhatókutyák', 'menun' => array(1,1)),
	'Örökbefogadható macskák' => array('fajl' => 'Örökbefogadható macskák', 'szoveg' => 'Örökbefogadható macskák', 'menun' => array(1,1)),
	'Gazdára Talált' => array('fajl' => 'Gazdára Talált', 'szoveg' => 'Gazdára Talált', 'menun' => array(1,1)),
    'Kapcsolat' => array('fajl' => 'Kapcsolat', 'szoveg' => 'Kapcsolat', 'menun' => array(1,1)),
    'Belépés' => array('fajl' => 'Belépés', 'szoveg' => 'Belépés', 'menun' => array(1,0)),
    'Kilepes' => array('fajl' => 'Kilepes', 'szoveg' => 'Kilépés', 'menun' => array(0,1)),
    'Regisztral' => array('fajl' => 'Regisztral', 'szoveg' => 'Regisztrál', 'menun' => array(1,0))
);

$hiba_oldal = array ('fajl' => '404', 'szoveg' => 'A keresett oldal nem található!');
?>

<?php
    $MAPPA = './kepek/';
    $TIPUSOK = array ('.jpg', '.png');
    $MEDIATIPUSOK = array('image/jpeg', 'image/png');
    $DATUMFORMA = "Y.m.d. H:i";
    $MAXMERET = 500*1024;
?>