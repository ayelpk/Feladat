

CREATE DATABASE `felhasznalok`
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `felhasznalok` (
  `id` int(10) UNSIGNED NOT NULL,
  `csaladi_nev` varchar(45) NOT NULL DEFAULT '',
  `uto_nev` varchar(45) NOT NULL DEFAULT '',
  `bejelentkezes` varchar(12) NOT NULL DEFAULT '',
  `jelszo` varchar(40) NOT NULL DEFAULT ''
) 
ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;



INSERT INTO `felhasznalok` (`id`, `csaladi_nev`, `uto_nev`, `bejelentkezes`, `jelszo`) VALUES
(1, 'Családi_1', 'Utónév_1', 'Login1', 'ghkjk1654'),
(2, 'Családi_2', 'Utónév_2', 'Login2', 'hdtyxfx542'),
(3, 'Családi_3', 'Utónév_3', 'Login3', 'seydgys2q35'),
(4, 'Családi_4', 'Utónév_4', 'Login4', '123q234afys'),
(5, 'Családi_5', 'Utónév_5', 'Login5', 'dryxghfj24'),
(6, 'Családi_6', 'Utónév_6', 'Login6', 'edhyx5'),
(7, 'Családi_7', 'Utónév_7', 'Login7', 'edhed546sea425'),
(8, 'Családi_8', 'Utónév_8', 'Login8', 'dhrzdxh6'),
(9, 'Családi_9', 'Utónév_9', 'Login9', 'ísrgyx6'),
(10, 'Családi_10', 'Utónév_10', 'Login10', '656rshdct6'),
(11, 'Családi_11', 'Utónév_11', 'Login11', 'sygdsdxghzdj4'),
(12, 'Családi_12', 'Utónév_12', 'Login12', 'hjklhk6486plp');


ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`id`);


--
ALTER TABLE `felhasznalok`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

