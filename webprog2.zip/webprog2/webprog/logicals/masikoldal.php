<a href="index.php">Főoldal</a>
<?php
if(!isset($_SESSION['login'])) echo '<a href="belepes.php">Belépés</a> ';
else echo '<a href="kilepes.php">Kilépés</a>';

echo "<h2>";
if(isset($_SESSION['login']))
echo "Be van jelentkezve: ".$_SESSION['login']." ".$_SESSION['csn']." ".$_SESSION['un'];
else
echo "Nincs bejelentkezve";
echo "</h2>";
?>