<?php
session_start();
if(isset($_POST['felhasznalo']) && isset($_POST['jelszo'])) {
try {

$dbh = new PDO('mysql:host=localhost;dbname=felhasznalo', 'root', '',
array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
$dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');

$sqlSelect = "select id, csaladi_nev, uto_nev from felhasznalok where bejelentkezes =
:bejelentkezes and jelszo = sha1(:jelszo)";
$sth = $dbh->prepare($sqlSelect);
$sth->execute(array(':bejelentkezes' => $_POST['felhasznalo'], ':jelszo' => $_POST['jelszo']));
$row = $sth->fetch(PDO::FETCH_ASSOC);
if($row) {
$_SESSION['csn'] = $row['csaladi_nev'];
$_SESSION['un'] = $row['uto_nev'];

$_SESSION['login'] = $_POST['felhasznalo'];
}
else{
echo "<h2>A bejelentkezés nem sikerült!</h2>";
session_unset();
}
}
catch (PDOException $e) {
echo "Hiba: ".$e->getMessage();
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>MySql</title>
<meta charset="utf-8">
</head>
<body>
<?php include("felul.php"); ?>
<form method = "post">
<fieldset>
<legend>Bejelentkezés</legend>
<br>
<input type="text" name="felhasznalo" placeholder="felhasználó"
required><br><br> <input type="password" name="jelszo" placeholder="jelszó"
required><br><br> <input type="submit" name="belepes" value="Belépés">
<br>&nbsp;
</fieldset>
</form>
</body>
</html>