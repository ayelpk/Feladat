<?php
session_start();
session_unset();
include("felul.php");
echo "<H3>A kijelentkezés oldal tartalma.... </H3>";
?>